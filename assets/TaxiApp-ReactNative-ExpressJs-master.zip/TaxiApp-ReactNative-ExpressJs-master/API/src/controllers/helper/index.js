import EmailVerification  from "./emailVerification";
import PhoneVerification from "./phoneVerification";
export{
    EmailVerification,
    PhoneVerification
}
