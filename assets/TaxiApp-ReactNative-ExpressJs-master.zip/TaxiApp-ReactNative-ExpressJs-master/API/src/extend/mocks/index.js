import dummy from './dummy';
import variable from './variable';

export { dummy, variable };
