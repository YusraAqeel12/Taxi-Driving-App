module.exports= {
   urlPrefix: '/api/v1',
   driverToken: '',
   databaseName: 'test?',
};
