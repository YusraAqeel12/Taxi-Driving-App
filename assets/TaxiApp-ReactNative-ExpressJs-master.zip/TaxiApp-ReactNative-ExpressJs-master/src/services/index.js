import { riderSignIn, saveRiderDoc } from './rider';
import { driverSignIn, saveDriverDoc } from './driver';

export default {
   driverSignIn,
   riderSignIn,
   saveDriverDoc,
   saveRiderDoc,
};
