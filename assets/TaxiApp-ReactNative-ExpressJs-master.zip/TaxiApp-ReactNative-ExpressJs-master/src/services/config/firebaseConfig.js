
export default firebaseConfig = {
   apiKey: '',
   authDomain: '',
   databaseURL: '',
   projectId: '',
   storageBucket: '',
   messagingSenderId: '',
   appId: '',
   measurementId: '',
};
