import customDrawerContentComponent from './riderDrawerContainer';

export default {
   customDrawerContentComponent,
};
