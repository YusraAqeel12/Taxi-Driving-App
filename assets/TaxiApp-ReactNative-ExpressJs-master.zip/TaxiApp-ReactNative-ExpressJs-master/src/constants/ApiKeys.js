export default {
   FirebaseConfig: {
      apiKey: 'AIzaSyCMauK6fAP-qAWRy95-tmWk2s22i4z6HGo',
      authDomain: 'mytaxiapp-5ad6d.firebaseapp.com',
      databaseURL: 'https://mytaxiapp-5ad6d.firebaseio.com',
      projectId: 'mytaxiapp-5ad6d',
      storageBucket: 'mytaxiapp-5ad6d.appspot.com',
      messagingSenderId: '70593916704',
   },
   GoolePlaces: 'AIzaSyANWRmdcfG4hksdtmVYxnqKCIsfW__rsVY',
};
