export default styles = {
   primaryColor: '',
   secondaryColor: '',
   tintColor: '',
};
