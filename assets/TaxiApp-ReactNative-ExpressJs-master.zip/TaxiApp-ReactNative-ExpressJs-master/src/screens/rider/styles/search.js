import { StyleSheet } from 'react-native';
export default styles = StyleSheet.create({
   searchIcon: {
      color: '#42A5F5',
      marginTop: 8,
      marginLeft: 10,
   },
});
