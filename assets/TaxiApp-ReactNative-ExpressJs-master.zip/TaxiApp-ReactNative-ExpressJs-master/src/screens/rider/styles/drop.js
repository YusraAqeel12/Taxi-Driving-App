import { StyleSheet } from 'react-native';
export default styles = StyleSheet.create({
   containerView: {
      flex: 1,
      backgroundColor: '#ffffff',
   },
   map: {
      height: 600,
      marginTop: 0,
   },
});
